import java.util.List;
import org.fog.entities.FogDevice;

public class RoundRobin {
    private static int index = 0;

    public static FogDevice select(List<FogDevice> nodes) {
        FogDevice node = nodes.get(index % nodes.size());
        index++;
        return node;
    }
}