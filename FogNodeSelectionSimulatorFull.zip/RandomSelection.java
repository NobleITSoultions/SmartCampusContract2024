import java.util.List;
import java.util.Random;
import org.fog.entities.FogDevice;

public class RandomSelection {
    public static FogDevice select(List<FogDevice> nodes) {
        Random rand = new Random();
        return nodes.get(rand.nextInt(nodes.size()));
    }
}