import java.util.List;
import org.fog.entities.FogDevice;

public class FuzzyLogicTrust {
    public static FogDevice select(List<FogDevice> nodes) {
        FogDevice best = null;
        double maxScore = -1;
        for (FogDevice node : nodes) {
            double trust = TrustManager.getTrustScore(node);
            double load = node.getHost().getUtilizationOfCpu() * 100;
            double score = (trust >= 0.8 && load <= 50) ? 1.0 : (trust >= 0.6 && load <= 70 ? 0.75 : 0.4);
            if (score > maxScore) {
                maxScore = score;
                best = node;
            }
        }
        return best;
    }
}