import java.util.List;
import org.fog.entities.FogDevice;

public class MinMinScheduling {
    public static FogDevice select(List<FogDevice> nodes, Task task) {
        FogDevice bestNode = null;
        double minTime = Double.MAX_VALUE;

        for (FogDevice node : nodes) {
            double execTime = task.getSize() / (1000 - node.getHost().getUtilizationOfCpu() * 1000 + 1);
            if (execTime < minTime) {
                minTime = execTime;
                bestNode = node;
            }
        }

        return bestNode;
    }
}