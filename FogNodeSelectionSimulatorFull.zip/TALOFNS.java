import java.util.List;
import org.fog.entities.FogDevice;

public class TALOFNS {
    private static final double TRUST_THRESHOLD = 0.7;
    private static final double MAX_LOAD = 80.0;
    private static final double ALPHA = 0.6;
    private static final double BETA = 0.4;

    public static FogDevice select(List<FogDevice> nodes, Task task) {
        FogDevice best = null;
        double bestScore = -1;

        for (FogDevice node : nodes) {
            double trust = TrustManager.getTrustScore(node);
            double load = node.getHost().getUtilizationOfCpu() * 100;
            if (trust >= TRUST_THRESHOLD && load <= MAX_LOAD) {
                double latency = QoSMonitor.getEstimatedLatency(node);
                double score = ALPHA * (1.0 / latency) + BETA * trust;
                if (score > bestScore) {
                    bestScore = score;
                    best = node;
                }
            }
        }

        return best;
    }
}