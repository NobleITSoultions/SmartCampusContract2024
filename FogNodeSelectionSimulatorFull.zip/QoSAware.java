import java.util.List;
import org.fog.entities.FogDevice;

public class QoSAware {
    public static FogDevice select(List<FogDevice> nodes) {
        FogDevice best = null;
        double bestScore = -1;

        for (FogDevice node : nodes) {
            double trust = TrustManager.getTrustScore(node);
            double latency = QoSMonitor.getEstimatedLatency(node);
            double load = node.getHost().getUtilizationOfCpu() * 100;
            double score = 0.5 * (1.0 / latency) + 0.3 * trust + 0.2 * (1.0 / (load + 1));
            if (score > bestScore) {
                bestScore = score;
                best = node;
            }
        }

        return best;
    }
}