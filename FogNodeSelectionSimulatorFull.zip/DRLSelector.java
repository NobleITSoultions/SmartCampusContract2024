import java.util.List;
import org.fog.entities.FogDevice;

public class DRLSelector {
    public static FogDevice select(List<FogDevice> nodes) {
        FogDevice best = null;
        double maxReward = -1;

        for (FogDevice node : nodes) {
            double trust = TrustManager.getTrustScore(node);
            double latency = QoSMonitor.getEstimatedLatency(node);
            double load = node.getHost().getUtilizationOfCpu() * 100;
            double reward = 0.5 * trust + 0.3 * (1.0 / latency) + 0.2 * (1.0 / (load + 1));
            if (reward > maxReward) {
                maxReward = reward;
                best = node;
            }
        }

        return best;
    }
}