import java.util.List;
import java.util.Random;
import org.fog.entities.FogDevice;

public class ProximityBased {
    public static FogDevice select(List<FogDevice> nodes) {
        return nodes.get(new Random().nextInt(nodes.size())); // Mock proximity
    }
}