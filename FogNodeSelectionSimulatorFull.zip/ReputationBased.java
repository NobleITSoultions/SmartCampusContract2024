import java.util.List;
import org.fog.entities.FogDevice;

public class ReputationBased {
    public static FogDevice select(List<FogDevice> nodes) {
        FogDevice best = null;
        double maxTrust = -1;
        for (FogDevice node : nodes) {
            double trust = TrustManager.getTrustScore(node);
            if (trust > maxTrust) {
                maxTrust = trust;
                best = node;
            }
        }
        return best;
    }
}